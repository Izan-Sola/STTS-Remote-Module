// remote.js
//
// Two jobs, both optional (nothing changes until config.json "brain" is set):
//
//   deviceRouter()  → /device/<op>: lets the brain use THIS machine's screen,
//                     VS Code companion, popup and pi. Requires brain.token.
//   brainPrompt()   → replaces the local `pi -p` run: sends the transcript to
//                     the brain, streams the reply back in the same SSE shape
//                     the frontend already understands.
import { Router } from 'express'
import crypto from 'node:crypto'
import cfg from './config.js'
import { createLocalDevice } from './deviceLocal.js'

const local = createLocalDevice({
    // live view of config.json "timeouts" so edits apply without a restart
    timeouts: new Proxy({}, { get: (_, k) => cfg.timeouts?.[k] }),
    companionUrl: process.env.VSCODE_COMPANION_URL || cfg.companionUrl || 'http://localhost:8768',
    gate: {
        url: new URL(cfg.brain.url).origin,
        token: cfg.brain.token,
        deviceId: cfg.brain.deviceId,
    },
})

// op → handler(body) → JSON
const OPS = {
    screenshot: async () => {
        const { buffer, via } = await local.screenshot()
        return { base64: buffer.toString('base64'), via }
    },
    ask: async ({ prompt }) => {
        try { return { value: await local.askUser(prompt) } }
        catch (e) { if (e.cancelled) return { cancelled: true }; throw e }
    },
    'active-file': () => local.activeFile(),
    'apply-edit': ({ path, content }) => local.applyEdit(path, content),
    'create-file': ({ path, content, overwrite }) => local.createFile(path, content, overwrite),
    pi: async ({ prompt }) => ({ output: await local.runPi(prompt) }),
}

function authorized(req) {
    const want = cfg.brain?.token
    if (!want) return false // no token configured → device endpoints stay closed
    const given = Buffer.from((req.headers.authorization ?? '').replace(/^Bearer\s+/i, ''))
    const key = Buffer.from(want)
    return given.length === key.length && crypto.timingSafeEqual(given, key)
}

export function deviceRouter() {
    const router = Router()
    router.use((req, res, next) => authorized(req) ? next() : res.status(401).json({ error: 'unauthorized' }))
    router.post('/:op', async (req, res) => {
        const op = OPS[req.params.op]
        if (!op) return res.status(404).json({ error: 'unknown op' })
        try {
            res.json(await op(req.body ?? {}))
        } catch (e) {
            res.status(e.status || 500).json({ error: e.message })
        }
    })
    return router
}

export async function brainPrompt(req, res) {
    const text = (req.body?.text || '').trim()
    if (!text) return res.status(400).json({ error: 'no text' })

    res.setHeader('Content-Type', 'text/event-stream')
    res.setHeader('Cache-Control', 'no-cache, no-transform')
    res.flushHeaders?.()
    const send = (event, data) => !res.writableEnded && res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`)

    const ac = new AbortController()
    res.on('close', () => ac.abort())

    send('start', { prompt: text })
    try {
        const { url, token, deviceId, timeoutMs = 660_000 } = cfg.brain
        const r = await fetch(`${url.replace(/\/$/, '')}/turn`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify({ text, deviceId }),
            signal: AbortSignal.any([ac.signal, AbortSignal.timeout(timeoutMs)]),
        })
        const data = await r.json().catch(() => ({}))
        if (!r.ok) throw new Error(data.error || `brain HTTP ${r.status}`)
        send('chunk', { text: data.reply ?? '' })
        send('done', { code: 0 })
    } catch (e) {
        if (e.name !== 'AbortError') send('error', { message: `brain: ${e.message}` })
    }
    res.end()
}